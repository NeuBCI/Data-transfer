import torch
import torch.nn as nn
from utils.functions import trainNetwork, testNetwork
from mAtt.mAtt import mAtt_bci
from utils.GetBci2a import getAllDataloader
import os
import argparse
import sys
#--------------------------------------
from datetime import datetime
import numpy as np
from sklearn.model_selection import StratifiedKFold
import random


script_path, script_name = os.path.split(os.path.abspath(__file__))
title = script_name[:-3] + ''
exp_time = datetime.now().strftime('%Y%m%d-%H%M%S')
model_path = script_path + '/record/'+script_name+'_'+exp_time+'/'
masterPath = os.path.dirname(script_path)
eeg_path=masterPath+'/Data/proccessed/'
sys.path.insert(1, masterPath)
from TSA_modal_EEG4 import Pack_dataloader

data_set='hypub' # hypub MI5
eeg_subject_dict={
    'hypub':list(range(0,29)),#list(range(29))
    'MI5':list(range(0,28)),#[2,3,14],#[4,6,8,9,13], #
    }
    
n_folder=5
val_ratio = {'hypub':1/4,'MI5':1/5}[data_set]
seed=0

batch_size={'hypub':60,'MI5':40}[data_set]

def set_seed(seed,cuda=False):
    random.seed(seed)
    torch.manual_seed(seed)
    if cuda:
        torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)

set_seed(seed)
#--------------------------------------
ap = argparse.ArgumentParser()
ap.add_argument('--repeat', type=int, default=1, help='No.xxx repeat for training model')
ap.add_argument('--sub', type=int, default=1, help='subjectxx you want to triain')
ap.add_argument('--lr', type=float, default=5e-4, help='learning rate')
ap.add_argument('--wd', type=float, default=1e-1, help='weight decay')
ap.add_argument('--iterations', type=int, default=350, help='number of training iterations')
ap.add_argument('--epochs', type=int, default=3, help='number of epochs that you want to use for split EEG signals')
# ap.add_argument('--bs', type=int, default=128, help='batch size')
ap.add_argument('--model_path', type=str, default='./checkpoint/bci2a/', help='the folder path for saving the model')
# ap.add_argument('--data_path', type=str, default='data/BCICIV_2a_mat/', help='data path')
args = vars(ap.parse_args([]))

# print(f'subject{args["sub"]}')
# trainloader, validloader, testloader = getAllDataloader(subject=args['sub'], 
#                                                         ratio=8, 
#                                                         data_path=args['data_path'], 
#    
# 
# 
#                                                      bs=args['bs'])
acc_all=[]
for subject in eeg_subject_dict[data_set]:
    print(data_set,subject)
    raw=np.load(eeg_path+data_set+'_bpc_'+str(subject)+'.npz')
    eeg,label,eeg_fs,eeg_ch_names=raw['data_all'],raw['label_all'],raw['fs'],raw['ch_names']
    eeg=eeg[:,np.newaxis,:,:]
    n_chan=eeg.shape[2]
    n_class=len(set(label))
    # if data_set=='hypub':
    #     eeg=eeg/5
    cv_list=np.load(masterPath+'/Data/'+data_set+'_cvlistS.npz',allow_pickle=True)['train_test_list']
    cv_list=cv_list[subject]

    acc_cv=[]
    acc_cv2=[]
    record_cv=[]
    i_cv=-1
    for train_index, test_index in cv_list:
        i_cv+=1
        # split data
        X_train_EEG, X_test_EEG = eeg[train_index], eeg[test_index]        
        y_train, y_test = label[train_index], label[test_index]

        cv = StratifiedKFold(n_splits=int(1/val_ratio),shuffle=True,random_state=seed)
        train_index2,val_index=list(cv.split(X_train_EEG,y_train))[0]

        X_train_EEG, X_val_EEG = X_train_EEG[train_index2], X_train_EEG[val_index]
        
        y_train, y_val = y_train[train_index2], y_train[val_index]
        print(X_train_EEG.shape,)
        print(X_val_EEG.shape,)
        print(X_test_EEG.shape,)

        # pack data
        dataloader_EEG_train = Pack_dataloader(X_train_EEG,y_train,batch_size,shuffle=True)
        dataloader_EEG_val = Pack_dataloader(X_val_EEG,y_val,1,shuffle=False)
        dataloader_EEG_test = Pack_dataloader(X_test_EEG,y_test,1,shuffle=False)
        

        net = mAtt_bci(args['epochs'],n_chan,n_class).cpu()
        # net = net.cuda()

        # args.pop('bs')
        # args.pop('data_path')
        trainNetwork(net, 
                    dataloader_EEG_train, 
                    dataloader_EEG_val, 
                    dataloader_EEG_test,
                    **args
                    )
        net = torch.load(os.path.join(args["model_path"], f'repeat{args["repeat"]}_sub{args["sub"]}_epochs{args["epochs"]}_lr{args["lr"]}_wd{args["wd"]}.pt'))    
        acc = testNetwork(net, dataloader_EEG_test)    
        print(f'{acc*100:.2f}')

        acc_cv.append(acc)

    print(np.mean(acc_cv))
    acc_all.append(acc_cv)

acc_all=np.array(acc_all)
acc_sub=acc_all.mean(axis=1)
print(acc_sub)

import xlwt

workbook = xlwt.Workbook()
worksheet = workbook.add_sheet('sheet1')

for isub in range(len(acc_sub)):    
    worksheet.write(0, isub, acc_sub[isub])

worksheet.write(0, isub+3, title+'_'+exp_time+'r') 

workbook.save(masterPath + '/record/'+title+'_'+exp_time+'.xls')