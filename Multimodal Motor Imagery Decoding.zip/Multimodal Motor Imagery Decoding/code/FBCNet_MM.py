#!/usr/bin/env python
# coding: utf-8
"""

10 fold cross-validation classification analysis of BCI Comp IV-2a and Korea datasets
@author: Ravikiran Mane

"""
import warnings
warnings.filterwarnings('ignore')

import numpy as np
import torch
import sys
import os
import time
import xlwt
import csv
import random
import math
import copy
from statistics import mean

masterPath = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(1, masterPath+ '/centralRepo')
_, file_name = os.path.split(os.path.abspath(__file__))
folder_path=os.path.dirname(os.path.dirname(masterPath))
sys.path.insert(1, folder_path+'/')
# from eegDataset import eegDataset
from eegDataset import eegDataset
from baseModel import baseModel
import networks
import transforms
from saveData import fetchData
from FBCSP_class import filter_bank
# reporting settings
debug = False

from sklearn.model_selection import train_test_split,\
    LeavePOut,KFold,StratifiedKFold,RepeatedStratifiedKFold

import datetime

import pandas as pd
pd.options.display.float_format = '{:.4f}'.format
#==========================================================
os.environ["CUDA_VISIBLE_DEVICES"] = '0'
#==========================================================

# path=folder_path+'/Data/BCICIV_2a_gdf/'
eeg_path=folder_path+'/Data/proccessed/'

title = file_name[:-3] + ''
experiment_time=datetime.datetime.now().strftime("%Y%m%d-%H%M%S")

data_set='hypub' # hypub MI5
eeg_subject_dict={
    'hypub':list(range(0,1)),#list(range(29))
    'MI5':list(range(0,18)),#[2,3,14],#[4,6,8,9,13], #
    }
n_folder=5
# n_epochs={'hypub':150,'MI5':100}[data_set]
val_ratio = {'hypub':1/4,'MI5':1/5}[data_set]

resample_rate=200
freq_bands=[[i*4+4,i*4+8] for i in range(9)] # +[[8,32]]
filter_type='iir'
filt_order=5
FB=filter_bank(freq_bands, resample_rate, filt_order,filter_type)

from torch.utils.data import Dataset
class Pack_Dataset(Dataset):
    def __init__(self, data, labels,):
        self.data = data
        self.labels = labels

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        data=torch.from_numpy(self.data[idx,]).float() #.float().to(torch.float16)
        label=torch.from_numpy(np.asarray(self.labels[idx,])).long()
        return {'data':data,'label':label}



#%% Set the defaults use these to quickly run the network
datasetId = 0
network = 'FBCNet'
nGPU = 0
subTorun= None
selectiveSubs = False


#%% Define all the model and training related options here.
config = {}

# Data load options:
config['preloadData'] = False # whether to load the complete data in the memory

# Random seed
config['randSeed']  = 20190821

# Network related details
config['network'] = network
config['batchSize'] = 16

if data_set=='hypub':
    config['modelArguments'] = {'nChan': 20, 'nTime': 2000, 'dropoutP': 0.5,
                                'nBands':9, 'm' : 32, 'temporalLayer': 'LogVarLayer',
                                'nClass': 2, 'doWeightNorm': True}
elif data_set=='MI5':
    config['modelArguments'] = {'nChan': 44, 'nTime': 2000, 'dropoutP': 0.5,
                                'nBands':9, 'm' : 32, 'temporalLayer': 'LogVarLayer',
                                'nClass': 5, 'doWeightNorm': True}

# Training related details    
config['modelTrainArguments'] = {'stopCondi':  {'c': {'Or': {'c1': {'MaxEpoch': {'maxEpochs': 1500, 'varName' : 'epoch'}},
                                                    'c2': {'NoDecrease': {'numEpochs' : 200, 'varName': 'valInacc'}} } }},
        'classes': [0,1], 'sampler' : 'RandomSampler', 'loadBestModel': True,
        'bestVarToCheck': 'valInacc', 'continueAfterEarlystop':False,'lr': 1e-3}
        
if data_set=='hypub':
    config['modelTrainArguments']['classes'] = [0,1] # 4 class data
elif data_set=='MI5':
    config['modelTrainArguments']['classes'] = [0,1,2,3,4] # 4 class data

config['transformArguments'] = None

# add some more run specific details.
config['cv'] = 'subSpecific-Kfold'
config['kFold'] = 10
config['data'] = 'raw'
config['subTorun'] = subTorun


# network initialization details:
config['loadNetInitState'] = True
config['loadNetInitState'] = True
config['pathNetInitState'] = config['network'] + '_'+ data_set

#%% Define data path things here. Do it once and forget it!
# Input data base folder:
toolboxPath = os.path.dirname(masterPath)
# config['inDataPath'] = os.path.join(toolboxPath, 'data')

# Input data datasetId folders
if 'FBCNet' in config['network']:
    modeInFol = 'multiviewPython' # FBCNet uses multi-view data
else:
    modeInFol = 'rawPython'

# Output folder:
# Lets store all the outputs of the given run in folder.
config['outPath'] = os.path.join(toolboxPath, 'output')
config['outPath'] = os.path.join(config['outPath'], data_set, 'cv')

# Network initialization:
config['pathNetInitState'] = os.path.join(masterPath, 'netInitModels', config['pathNetInitState']+'.pth')
# check if the file exists else raise a flag
config['netInitStateExists'] = os.path.isfile(config['pathNetInitState'])

#%% Some functions that should be defined here
def setRandom(seed):
    '''
    Set all the random initializations with a given seed

    '''
    # Set np
    np.random.seed(seed)

    # Set torch
    torch.manual_seed(seed)

    # Set cudnn
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def excelAddData(worksheet, startCell, data, isNpData = False):
    '''
        Write the given max 2D data to a given given worksheet starting from the start-cell.
        List will be treated as a row.
        List of list will be treated in a matrix formate with inner list constituting a row.
        will return the modified worksheet which needs to be written to a file
        isNpData flag indicate whether the incoming data in the list is of np data-type
    '''
    #  Check the input type.
    if type(data) is not list:
        data = [[data]]
    elif type(data[0]) is not list:
        data = [data]
    else:
        data = data

    # write the data. starting from the given start cell.
    rowStart = startCell[0]
    colStart = startCell[1]

    for i, row in enumerate(data):
        for j, col in enumerate(row):
            if isNpData:
                worksheet.write(rowStart+i, colStart+j, col.item())
            else:
                worksheet.write(rowStart+i, colStart+j, col)

    return worksheet

def dictToCsv(filePath, dictToWrite):
    """
    Write a dictionary to a given csv file
    """
    with open(filePath, 'w') as csv_file:
        writer = csv.writer(csv_file)
        for key, value in dictToWrite.items():
            writer.writerow([key, value])

def splitKfold(idx1, k, doShuffle = True):
    '''
    Split the index from given list in k random parts.
    Returns list with k sublists.
    '''
    idx = copy.deepcopy(idx1)
    lenFold = math.ceil(len(idx)/k)
    if doShuffle:
        np.random.shuffle(idx)
    return [idx[i*lenFold:i*lenFold+lenFold] for i in range(k)]

def loadSplitFold(idx, path, subNo):
    '''
    Load the CV fold details saved in json formate.
    Returns list with k sublists corresponding to the k fold splitting.
    subNo is the number of the subject to load from. starts from 0
    '''
    import json
    with open(path) as json_file:
        data = json.load(json_file)
    data = data[subNo]
    # sort the values in sublists
    folds = []
    for i in list(set(data)):
        folds.append([idx[j] for (j, val) in enumerate(data) if val==i])

    return folds

def generateBalancedFolds(idx, label, kFold = 5):
    '''
    Generate a class aware splitting of the data index in given number of folds.
    Returns list with k sublists corresponding to the k fold splitting.
    '''
    from sklearn.model_selection import StratifiedKFold
    folds = []
    skf = StratifiedKFold(n_splits=kFold)
    for train, test in skf.split(idx, label):
        folds.append([idx[i] for i in list(test)])
    return folds

def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

#%%
# based on current date and time -> always unique!
randomFolder = str(time.strftime("%Y-%m-%d--%H-%M", time.localtime()))+ '-'+str(random.randint(1,1000))
config['outPath'] = os.path.join(config['outPath'], randomFolder,'')
# create the path
if not os.path.exists(config['outPath']):
    os.makedirs(config['outPath'])
print('Outputs will be saved in folder : ' + config['outPath'])

# Write the config dictionary
dictToCsv(os.path.join(config['outPath'],'config.csv'), config)

#%% Check and compose transforms
if config['transformArguments'] is not None:
    if len(config['transformArguments']) >1 :
        transform = transforms.Compose([transforms.__dict__[key](**value) for key, value in config['transformArguments'].items()])
    else:
        transform = transforms.__dict__[list(config['transformArguments'].keys())[0]](**config['transformArguments'][list(config['transformArguments'].keys())[0]])
else:
    transform = None


#%% Check and load the model
#import networks
if config['network'] in networks.__dict__.keys():
    network = networks.__dict__[config['network']]
else:
    raise AssertionError('No network named '+ config['network'] + ' is not defined in the networks.py file')



#%% Let the training begin
trainResults = []
valResults = []
testResults = []
acc_c_all = np.zeros((len(eeg_subject_dict[data_set]), n_folder))
    
for subject in eeg_subject_dict[data_set]:

    start = time.time()
    print(data_set,subject)
    raw=np.load(eeg_path+data_set+'_bpc_'+str(subject)+'.npz')
    data_t,label_t,eeg_fs,eeg_ch_names=raw['data_all'],raw['label_all'],raw['fs'],raw['ch_names']
    
    if data_set=='hypub':
        data_t=data_t/5

    data_t=data_t.squeeze()
    data_t.shape
    classNum=len(set(label_t))
    data_t=FB.filt(data_t)

    data_t=data_t.transpose(1,2,3,0)

    cv_list=np.load(folder_path+'/Data/'+data_set+'_cvlistS.npz',allow_pickle=True)['train_test_list']
    cv_list=cv_list[subject]

    trainResultsCV = []
    valResultsCV = []
    testResultsCV = []

    for j, (majority_indice, minority_indice) in enumerate(cv_list): 

        train_indice=majority_indice
        test_indice=minority_indice
           

        print('target_subject: {}'.format(j))


        data_t_train = data_t[train_indice]
        label_t_train = label_t[train_indice]
        data_t_test = data_t[test_indice]
        label_t_test = label_t[test_indice]
        data_t_train, data_t_val, label_t_train, label_t_val = \
            train_test_split(data_t_train, label_t_train, test_size=val_ratio,
                                stratify=label_t_train, random_state=config['randSeed'])

        testData={'data':data_t_test,'label':label_t_test}
        trainData={'data':data_t_train,'label':label_t_train}
        valData={'data':data_t_val,'label':label_t_val}

        testData=Pack_Dataset(data_t_test,label_t_test)
        trainData=Pack_Dataset(data_t_train,label_t_train)
        valData=Pack_Dataset(data_t_val,label_t_val)

        # data_t_test.shape

        # Load the net and print trainable parameters:
        net = network(**config['modelArguments'])
        print('Trainable Parameters in the network are: ' + str(count_parameters(net)))

        #%% check and load/save the the network initialization.
        if config['loadNetInitState']:
            if config['netInitStateExists']:
                netInitState = torch.load(config['pathNetInitState'])
            else:
                setRandom(config['randSeed'])
                net = network(**config['modelArguments'])
                netInitState = net.to('cpu').state_dict()
                torch.save(netInitState, config['pathNetInitState'])        

        # Call the network
        net = network(**config['modelArguments'])
        net.load_state_dict(netInitState, strict=False)
        outPathSub = os.path.join(config['outPath'], 'sub'+ str(subject), 'fold'+ str(j))
        model = baseModel(net=net, resultsSavePath=outPathSub, batchSize= config['batchSize'], nGPU = nGPU)
        model.train(trainData, valData, testData, **config['modelTrainArguments'])

        # extract the important results.
        trainResultsCV.append([d['results']['trainBest'] for d in model.expDetails])
        valResultsCV.append([d['results']['valBest'] for d in model.expDetails])
        testResultsCV.append([d['results']['test'] for d in model.expDetails])
        acc_c_all[subject,j]=testResultsCV[-1][0]['acc']

print(acc_c_all)

acc_c_mean=np.mean(acc_c_all,axis=1)

import xlwt
import numpy as np
workbook = xlwt.Workbook()
worksheet = workbook.add_sheet('sheet1')

for isub in range(len(acc_c_mean)):    
    worksheet.write(0, isub, acc_c_mean[isub]) 
worksheet.write(0, isub+3, title+'_'+experiment_time+'r') 
workbook.save(folder_path + '/record/'+data_set+'_'+experiment_time+'.xls')