'''
Use the keras-TimeDistributed function to build the CNN-LSTM model
'''


from __future__ import print_function

import numpy as np
import random
import tensorflow as tf

from keras.models import Sequential
from keras.models import Model
from keras.models import load_model
from keras.layers import Dense, Dropout, Activation, Flatten
from keras.layers import LSTM
from keras.layers import Conv2D, MaxPooling2D
from keras.layers import TimeDistributed
from keras.layers import GlobalAveragePooling2D
from keras.layers import Input, Reshape, Permute
from keras.layers import multiply, Lambda, RepeatVector, Concatenate
from keras.layers import BatchNormalization
from keras.optimizers import Adam
from keras import regularizers

import keras.backend as K

from keras.utils import to_categorical
from keras.callbacks import ModelCheckpoint, EarlyStopping

from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.preprocessing import MinMaxScaler
from datetime import datetime

import sys
lr_num=0.001
hidden_lstm=16
dropout_num=0.3
head_num = 3
# subNum, lr_num, hidden_lstm, dropout_num, GPU_id = '1', '0.001', '16', '0.3', '1'

import os 
os.environ["CUDA_VISIBLE_DEVICES"] = '0'

import tensorflow as tf
import keras.backend.tensorflow_backend as ktf
config = tf.ConfigProto()
config.gpu_options.allow_growth=True
# config.gpu_options.per_process_gpu_memory_fraction = 0.35
session = tf.Session(config=config)
ktf.set_session(session)

#------------------------------------------
script_path, script_name = os.path.split(os.path.abspath(__file__))
title = script_name[:-3] + ''
masterPath = os.path.dirname(script_path)
exp_time = datetime.now().strftime('%Y%m%d-%H%M%S')
eeg_path=masterPath+'/Data/proccessed/'

data_set='MI5' # hypub MI5
eeg_subject_dict={
    'hypub':list(range(0,29)),#list(range(29))
    'MI5':list(range(0,28)),#[2,3,14],#[4,6,8,9,13], # 28
    }
n_folder=5
val_ratio = {'hypub':1/4,'MI5':1/5}[data_set]
seed=0


def seed_tensorflow(seed=0):
    os.environ['PYTHONHASHSEED']=str(seed)
    random.seed(seed)
    np.random.seed(seed)
    tf.random.set_random_seed(seed)
    os.environ['TF_DETRMINISTIC_OPS']='1'

seed_tensorflow(seed)

def squeeze_excitation_layer_input(x, out_dim):
    '''
    SE module performs inter-channel weighting.
    x: (16, 20, 1)
    '''
    ratio = 4
    temp_x = Reshape((16, 5, 4))(x)
    temp_x = Permute((2, 3, 1))(temp_x) # (5,4,16), start from 1
    squeeze = GlobalAveragePooling2D()(temp_x)
    
    excitation = Dense(units=out_dim // ratio)(squeeze)
    excitation = Activation('relu')(excitation)
    excitation = Dense(units=out_dim)(excitation)
    excitation = Activation('sigmoid')(excitation)
    excitation = Reshape((1,1,out_dim))(excitation)
    
    scale = multiply([temp_x,excitation]) # (5, 4, 16)

    scale = Permute((3, 1, 2))(scale) # (16, 5, 4)
    scale = Reshape((16, 20, 1))(scale)

    return scale

def squeeze_excitation_layer(x):
    '''
    SE module performs inter-channel weighting.
    '''
    ratio = 2
    out_dim = K.int_shape(x)[-1]
    squeeze = GlobalAveragePooling2D()(x)
    
    excitation = Dense(units=out_dim // ratio)(squeeze)
    excitation = Activation('relu')(excitation)
    excitation = Dense(units=out_dim)(excitation)
    excitation = Activation('sigmoid')(excitation)
    excitation = Reshape((1,1,out_dim))(excitation)
    
    scale = multiply([x,excitation])

    return scale

def soft_attention(x):
    '''
    apply soft_attention in channel-dim
    x: (None, dim_1, dim_2, channel)
    '''
    # SINGLE_ATTENTION_VECTOR = False
    channel_dim = int(x.shape[-1])
    # a = Dense(channel_dim, activation='softmax')(x)
    a = Dense(channel_dim, activation='softmax',
            kernel_regularizer=regularizers.l2(0.01),
            activity_regularizer=regularizers.l1(0.01))(x)
    # if SINGLE_ATTENTION_VECTOR:
    #     a = Lambda(lambda x: K.mean(x, axis=-1), name='a_mean')(a)
    #     a_probs = RepeatVector(channel_dim, name='attention_vec_single')(a)
    # else:
    #     a_probs = a
    output_attention_mul = multiply([x, a])
    output_attention_mul = Lambda(lambda x: K.sum(x, axis=-1, keepdims=True), name='a_sum')(output_attention_mul)
    print('sum output shape: {}'.format(int(output_attention_mul.shape[-1])))
    return output_attention_mul

def soft_attention_mask(x):
    '''
    soft attention mask module performs inter-channel weighting.
    x: (4, 16, 5)
    '''
    input_channels = int(x.shape[-1])
    output_mask = Conv2D(input_channels, (1, 1),
            kernel_regularizer=regularizers.l2(0.01),
            activity_regularizer=regularizers.l1(0.01))(x)
    output_mask = Conv2D(input_channels, (1, 1),
            kernel_regularizer=regularizers.l2(0.01),
            activity_regularizer=regularizers.l1(0.01))(output_mask)
    output_mask = Activation('sigmoid')(output_mask)
    output_soft = multiply([x, output_mask])
    return output_soft

classNumDict = {
    'readMe':'num_classes',
    'MI5':5,
    'hypub':2,
}

batch_size = 6400
num_classes = classNumDict[data_set]
epochs = 2000 #10000
# cnn_1, cnn_2, cnn_3 = 16, 8, 4
cnn_1 = 16
cnn_2 = cnn_1 // 2
cnn_3 = cnn_2 // 2
lstm_units = int(hidden_lstm)
dropoutRatio = float(dropout_num)

acc_all=[]
for subject in eeg_subject_dict[data_set]:
    print(data_set,subject)
    acc_cv=[]
    for i_cv in range(5):
        filename = '{}/{}_fbcspF_sub{}_fold{}.npz'.format(
                    eeg_path, data_set, subject, i_cv)

        data = np.load(filename)
        train_x = data['train_x']
        test_x = data['test_x']
        train_y = data['train_label']
        test_y = data['test_label']


        train_x_shape = train_x.shape
        train_x = train_x.reshape(train_x_shape[:3]+(num_classes, 4))
        train_x = np.transpose(train_x, (0, 1, 2, 4, 3)) # (:, :, 16, 4, 5)
        # train_x = train_x[:, :, :, :, np.newaxis]
        train_y = train_y # change to 0~4
        train_y = to_categorical(train_y)

        test_x_shape = test_x.shape
        test_x = test_x.reshape(test_x_shape[:3]+(num_classes, 4))
        test_x = np.transpose(test_x, (0, 1, 2, 4, 3)) # (:, :, 16, 4, 5)
        # test_x = test_x[:, :, :, :, np.newaxis]
        test_y = test_y# change to 0~4
        test_y = to_categorical(test_y)

        print(train_x.shape)
        print(train_y.shape)
        print(np.min(train_y))
        print(np.max(train_y))
# print(train_y[:30])
# print(test_y[:30])

# a = Input(shape = train_x.shape[2:]) # (None, 5, 4, 16)
# x = squeeze_excitation_layer(a)      # (None, 5, 4, 16)
# x = Permute((2, 3, 1))(x)            # (None, 4, 16, 5)
# x = soft_attention(x)                # (None, 4, 16, 5)
# x = Permute((2, 3, 1))(x)            # (None, 16, 5, 4)
# x = squeeze_excitation_layer(x)      # (None, 16, 5, 4)
# x = Flatten()(x)
# attention_model = Model(inputs=a, outputs=x)

        a = Input(shape = train_x.shape[2:]) # (None, 16, 4, 5)
        x = soft_attention(a)                # (None, 16, 4, 1)
        if head_num == 1:
            x = soft_attention_mask(x)
        else:
            x_conca = []
            for i in range(head_num):
                x_conca.append(soft_attention_mask(x))
            # x1 = soft_attention_mask(x)           # (None, 16, 4, 1)
            # x2 = soft_attention_mask(x)           # (None, 16, 4, 1)
            x = Concatenate(axis=-1)(x_conca)
        x = Flatten()(x)
        attention_model = Model(inputs=a, outputs=x)


        model = Sequential()
        model.add(TimeDistributed(attention_model, input_shape=train_x.shape[1:]))

# model.add(LSTM(64, dropout=0.2, recurrent_dropout=0.2, return_sequences=True))
# model.add(LSTM(64, dropout=0.2, recurrent_dropout=0.2, return_sequences=True))
        model.add(LSTM(lstm_units, dropout=dropoutRatio, recurrent_dropout=dropoutRatio, return_sequences=False))

        model.add(Dense(num_classes, activation='softmax'))

        print(model.summary())

        optimizer = Adam(lr=float(lr_num))
        model.compile(loss='categorical_crossentropy', 
                        optimizer=optimizer,
                        metrics=['accuracy'])

        filepath = script_path+'/temp_senet_bestWeight/{}/best_weights_sub{}_fold{}_multiHead{}.h5'.format(data_set, subject, i_cv,head_num)


        callbacks_list = []
        checkpoint = ModelCheckpoint(filepath, monitor='val_acc', verbose=0,
                                save_best_only=True, period=1)
        callbacks_list.append(checkpoint)
        earlyStopping = EarlyStopping(monitor='val_loss', patience=20)
        # callbacks_list.append(earlyStopping)

        model.fit(train_x, train_y,
                    batch_size=batch_size,
                    epochs=epochs,
                    validation_split=val_ratio,
                    callbacks = callbacks_list
                    )

        # load the best_acc model
        model = load_model(filepath)

        train_y_pred = model.predict(train_x)
        train_y_pred = np.argmax(train_y_pred, axis=1)

        train_y_real = np.argmax(train_y, axis=1)
        train_acc = accuracy_score(train_y_real.flatten(), train_y_pred.flatten()) 
        train_confu = confusion_matrix(train_y_real.flatten(), train_y_pred.flatten())
        print(train_acc)
        print(train_confu)

        test_y_pred = model.predict(test_x)
        test_y_pred = np.argmax(test_y_pred, axis=1)

        test_y_real = np.argmax(test_y, axis=1)
        test_acc = accuracy_score(test_y_real.flatten(), test_y_pred.flatten())
        test_confu = confusion_matrix(test_y_real.flatten(), test_y_pred.flatten())
        print(test_acc)
        print(test_confu)

        acc_cv.append(test_acc)
    
    acc_all.append(acc_cv)

    acc_all1=np.array(acc_all)
    acc_sub=acc_all1.mean(axis=1)
    mean_acc=np.mean(acc_all1,axis=(0,1))

    import xlwt
    workbook = xlwt.Workbook()
    worksheet = workbook.add_sheet('sheet1')

    for isub in range(len(acc_sub)):    
        worksheet.write(0, isub, acc_sub[isub])

    worksheet.write(0, isub+3, title+'_'+exp_time)
    workbook.save(script_path + '/record/'+title+'_'+exp_time+'.xls')
